package controllers;

import apimodels.Request;
import apimodels.TransformerQuery;

import play.mvc.Http;
import java.util.List;
import java.util.ArrayList;
import java.util.HashMap;
import java.io.FileInputStream;
import javax.validation.constraints.*;
@javax.annotation.Generated(value = "io.swagger.codegen.languages.JavaPlayFrameworkCodegen", date = "2019-11-08T23:25:48.604Z")

public class AsynchronousApiControllerImp implements AsynchronousApiControllerImpInterface {
    @Override
    public Request statusRequestIdGet(String requestId) throws Exception {
        //Do your magic!!!
        return new Request();
    }

    @Override
    public Request submitPost(TransformerQuery query) throws Exception {
        //Do your magic!!!
        return new Request();
    }

}
